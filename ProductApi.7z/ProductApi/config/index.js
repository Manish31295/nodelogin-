import 'dotenv/config'
dotenv.config();
export const {
    APP_PORT
} = process.env.PORT;