import express from 'express';
import errorHandler from './routes/middlewares/errorHandler';
import routes from './routes';
import 'dotenv/config'
const app = express();



app.use('/api',routes);


app.use(express.json());
app.use(errorHandler);
app.listen(APP_PORT, ()=>console.log(`listening at http://localhost:${APP_PORT}`));