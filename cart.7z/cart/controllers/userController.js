const mongoose = require("mongoose");
const Users = require("../model/userSchema")
const bcrypt = require("bcrypt")

const createRegister = async (req, res)=>{
    bcrypt.hash(req.body.password, 10, (err, hash)=>{
        if(err){
            return res.status(500).json({
                error:err
            })
        }else{
            let UserDoc = new Users({
                _id: new mongoose.Types.ObjectId,
                name:req.body.name,
                email:req.body.email,
                password:hash
            })
            UserDoc.save()
            .then(result=>{
                res.status(200).json({
                    newResult:result
                })
            }).catch(err=>{
                res.status(500).json({
                    newError:err
                })
            })
        }
    })    

    }


module.exports = {createRegister};


// try{
//     const {name, email, password} = req.body
//     let userDoc = new users({
//         name:name,
//         email:email,
//         password:password
//     })
//     userDoc.save()
//     .then(result=>{
//         res.s
//     })
//   }catch{

//   }
