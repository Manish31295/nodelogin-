const mongoose = require('mongoose')
const Schema = mongoose.Schema

const cartsSchema = new Schema({
    _id: mongoose.Types.ObjectId,
    name: {
        type: String,
        default:null

    },
    email: {
        type: String,
        default:null
 
    },
    password: {
        type: Number


    }

});

const Users = mongoose.model('users', cartsSchema)
module.exports = Users;
