const mongoose = require('mongoose')
const Schema = mongoose.Schema

const cartsSchema = new Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: {
        type: String,
        default:null

    },
    category: {
        type: String,
        default:null
 
    },
    model: {
        type: Number,
        default:0

    },
    desgination: {
        type: String,
        default:null

    },
    price: {
        type: Number,
        default:0
 
    }

});

const carts = mongoose.model('createCart', cartsSchema)
module.exports = carts;
