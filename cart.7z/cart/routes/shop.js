const express = require("express");
const router = express();
const shopProduct = require("../model/shop")
const carts = require("../model/product")



router.post("/store/addtocart", (req, res)=>{
    const shopData = new shopProduct({
        title:req.body.title,
        cartDetail:req.body.cartDetail,
        quantity:req.body.quantity
    })
    shopData.save()
    .then(response=>{
        res.json({
            message:"add to cart",
            response
        })
    })
    .catch(error=>{
        res.json({
            message:"no add to cart",
            error
        })
    })
});
router.get("/show/addtocart", (req, res)=>{
  carts.find()
  .then(result=>{
      res.json({
          message:"all add to cart",
          result:result
      })
  })
  .catch(error=>{
      res.json({
          message:"no cart",
          error
      })
  })
})



module.exports = router;