const express = require("express");
const app = express();
const port = process.env.PORT || "1000";
const mongoose = require("mongoose");
const bodyParser = require("body-parser")
const AdminRouter = require("./routes/admin");
const UserRouter = require("./routes/user")
const ShopRouter = require("./routes/shop");

//database connection
mongoose.connect("mongodb://localhost:27017/NodeDB",  { useNewUrlParser: true , useUnifiedTopology: true});

// IF ERROR
mongoose.connection.on('error', ()=>{
    console.log('connection failed')
});
mongoose.connection.once('open', ()=>{
    console.log('successfully connection')
});

// bodyParser
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json())
app.use(express.json())


//main Router
app.use('/api', AdminRouter);
app.use('/api', UserRouter);
app.use('/api', ShopRouter);

//error /


// web server connection
app.listen(port, ()=>{
    console.log(`server running on http://localhost:${port}`);
})