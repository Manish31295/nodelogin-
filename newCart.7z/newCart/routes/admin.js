const express = require("express");
const router = express.Router();
const AdminController = require("../controllers/admin");


router.post('/store', AdminController.storeProduct)
router.get('/show', AdminController.showProduct)
router.get('/:id', AdminController.oneProductShow)
router.delete('/:id', AdminController.deleteProduct)
router.put('/:id', AdminController.updateProduct)


module.exports = router;