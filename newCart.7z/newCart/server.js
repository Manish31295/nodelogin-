const express = require("express");
const app = express();;
const port = process.env.PORT || "1002";
const mongoose = require("mongoose");
const adminRouter = require("./routes/admin")
const bodyParser = require("body-parser");


// database connection by mongoose
mongoose.connect("mongodb://localhost:27017/NodeDB", { useNewUrlParser: true, useUnifiedTopology: true });
mongoose.connection.on("error", err=>{
    console.log("failed connection");
});
mongoose.connection.once( 'open', result=>{
    console.log('successfully connect')
})
//routes
app.use(adminRouter);
//middleware
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json())

//error /
app.use('/', (req, res)=>{
    res.status(200).json({
        message:"page not found"
    })
})

app.listen(port, ()=>{
    console.log(`server running on http://localhost:${port}`);
})