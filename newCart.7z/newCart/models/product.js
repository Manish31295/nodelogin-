const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const productSchema = new Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name:{
        type:String
  
    },
    category:{
        type:String

    },
    model:{
        type:Number
    },
    price:{
        type:Number

    }
});

const Product = mongoose.model("CreateProduct", productSchema)
module.export = Product;