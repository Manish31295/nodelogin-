const mongoose = require("mongoose");
const Product = require("../models/product")


//create product
const storeProduct = (req, res)=>{
    let product = new Product({
        _id: new mongoose.Types.ObjectId,
        name: req.body.name,
        category: req.body.category,
        model: req.body.model,
        price: req.body.price

    })
    product.save()
    .then(response=>{
        res.json({
            message:'cart Details Saved!',
            response
        })
    })
    .catch(error=>{
        res.json({
            message: 'An Error Occured!'
        })
    })
}

// Show Single product Details By product ID

const showProduct = async (req,res)=>{
    // res.send({message:"hii"})
   const data = await carts.find()
    .then(data=>{
        res.status(200).json({
            cartData:data
        })
    })
    .catch(err=>{
        res.status(500).json({
            error:err
        })
    })
}

//get any particuler data by Id from database
const oneProductShow = (req, res)=>{
    carts.findById(req.params.id)
    .then(result=>{
        res.status(200).json({
            oneData:result
        })
    })
    .catch(err=>{
        res.status(500).json({
            error:err
        })
    })
}

// delete product from database by id

const deleteProduct = (req, res)=>{
    carts.remove({_id:req.params.id})
    .then(result=>{
        res.status(200).json({
            message:"cart deleted from database",
            result:result
        })
    })
    .catch(err=>{
        res.status(500).json({
            message:"not delete",
            error:err
        })
    })
}

//update product

const updateProduct = (req, res)=>{
    carts.findOneAndUpdate({_id:req.params.id}, {
        $set:{
            name: req.body.name,
            category: req.body.category,
            model: req.body.model,
            price: req.body.price

          }
    })
    .then(result=>{
        res.status(200).json({
            message:"cart product update",
            result:result
        })
    })
    .catch(err=>{
        res.status(200).json({
            message:"not update cart product",
            error:err
        })
    })
}


module.exports = {storeProduct, showProduct, updateProduct, oneProductShow, deleteProduct};