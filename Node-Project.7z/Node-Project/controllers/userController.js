import UserModel from '../models/User.js';
class UserController{
    static home = (req, res)=>{
        res.render('index')
    }

    static registration = (req, res)=>{
        res.render('registration')
    }

    static createUserDoc = async (req, res)=>{
        try{
        // creating new document using model
        const doc = new UserModel({
            name:req.body.name,
            email:req.body.email,
            password:req.body.password
        })
        // saving document
        await doc.save()
        res.send("hello")
        }catch (error){

        }
    }

    static login = (req, res)=>{
        res.render('login')
    }
}
export default UserController;